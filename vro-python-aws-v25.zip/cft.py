import boto3
import random
import string
import json
import time

#
# This code checks if the input is null or blank
# @param variable: The variable to be checked
# @return: None
# @raise ValueError: If the variable is null or blank
#
def check_null_or_blank(variable):
    if variable is None or variable == '':
        raise ValueError('Variable is null or blank')

#
# This code generates a random key
# @param: None
# @return: The generated key
#
def generate_key():
    letters_and_digits = string.ascii_letters + string.digits
    return ''.join(random.choice(letters_and_digits) for i in range(20))

#
# This code generates temporary credentials using the STS AssumeRole operation
# @param inputs: The input parameters required to generate the temporary credentials
# @return: The temporary credentials
#
def generate_temp_credentials(inputs):
    sts_client = boto3.client(
        'sts',
        aws_access_key_id=inputs["aws_access_key"],
        aws_secret_access_key=inputs["aws_secret_key"],
        region_name=inputs["region_name"]
    )

    # Define the AssumeRole request parameters
    role_arn = inputs["role_arn"]
    role_session_name = generate_key()
    #print(role_session_name)
    # Send the AssumeRole request
    response = sts_client.assume_role(
        RoleArn=role_arn,
        RoleSessionName=role_session_name
    )
    # Extract the temporary credentials from the response
    access_key_id = response['Credentials']['AccessKeyId']
    secret_access_key = response['Credentials']['SecretAccessKey']
    session_token = response['Credentials']['SessionToken']

    return {
        "access_key_id": access_key_id,
        "secret_access_key": secret_access_key,
        "session_token": session_token
    }

#
# This code creates a CloudFormation client using the temporary credentials
# @param access_key_id: The temporary access key ID
# @param secret_access_key: The temporary secret access key
# @param session_token: The temporary session token
# @param target_region: The target region
# @return: The CloudFormation client
# 
def create_cfn_client(access_key_id, secret_access_key, session_token, target_region):
    # Use the temporary credentials to create a CloudFormation client in the target account
    cfn_client = boto3.client(
        'cloudformation',
        aws_access_key_id=access_key_id,
        aws_secret_access_key=secret_access_key,
        aws_session_token=session_token,
        region_name=target_region
    )  
    return cfn_client

#
# This code creates a ec2 client using the temporary credentials
# @param access_key_id: The temporary access key ID
# @param secret_access_key: The temporary secret access key
# @param session_token: The temporary session token
# @param target_region: The target region
# @return: The ec2 client
# 
def create_ec2_client(access_key_id, secret_access_key, session_token, target_region):
    # Use the temporary credentials to create a ec2 client in the target account
    ec2_client = boto3.client(
        'ec2',
        aws_access_key_id=access_key_id,
        aws_secret_access_key=secret_access_key,
        aws_session_token=session_token,
        region_name=target_region
    )  
    return ec2_client

#
# This code creates a rds client using the temporary credentials
# @param access_key_id: The temporary access key ID
# @param secret_access_key: The temporary secret access key
# @param session_token: The temporary session token
# @param target_region: The target region
# @return: The rds client
# 
def create_rds_client(access_key_id, secret_access_key, session_token, target_region):
    # Use the temporary credentials to create a rds client in the target account
    rds_client = boto3.client(
        'rds',
        aws_access_key_id=access_key_id,
        aws_secret_access_key=secret_access_key,
        aws_session_token=session_token,
        region_name=target_region
    )  
    return rds_client

#
# This code is the main function
# @param context: The Lambda context object
# @param inputs: The input parameters required to execute the action
# @return: The output of the action
# 
def handler(context, inputs):
    # Define the STS client

    #print("Inputs: ", inputs)
    responseData = ""
    
    # Check if the inputs are null or blank
    if(inputs is not None):
        check_null_or_blank(inputs["action"])
        check_null_or_blank(inputs["aws_access_key"])
        check_null_or_blank(inputs["aws_secret_key"])
        check_null_or_blank(inputs["region_name"])
        check_null_or_blank(inputs["role_arn"])
        check_null_or_blank(inputs["target_region"])
        check_null_or_blank(inputs["is_print_log_enabled"])
        
        if(inputs["cft_parameters"] != []):
            if(inputs["is_print_log_enabled"] == "true"):
                for item in inputs["cft_parameters"]:
                    print(item["ParameterKey"]+" : "+item["ParameterValue"])
        
        # Generate temporary credentials
        credentials = generate_temp_credentials(inputs);
        temp_access_key = credentials["access_key_id"]
        temp_secret_access_key = credentials["secret_access_key"]
        temp_session_token = credentials["session_token"]
        target_region = inputs["target_region"]
        
        # create cfn client
        client = create_cfn_client(temp_access_key, temp_secret_access_key, temp_session_token, target_region)
        
    # Execute based on action
    if(inputs["action"] == "executeCFT"):
        check_null_or_blank(inputs["template_name"])
        check_null_or_blank(inputs["cft_parameters"])
        responseData = trigger_cft(inputs["template_name"], inputs["cft_parameters"], inputs["is_print_log_enabled"], client)
        pass
    elif(inputs["action"] == "executeCFTWithUrl"):
        check_null_or_blank(inputs["template_url"])
        check_null_or_blank(inputs["cft_parameters"])
        responseData = trigger_cft(inputs["template_url"], inputs["cft_parameters"], inputs["is_print_log_enabled"], client)
        pass
    elif(inputs["action"] == "getCFTStatus"):
        check_null_or_blank(inputs["cft_parameters"])
        stackName = next(item for item in inputs["cft_parameters"] if item["ParameterKey"] == "stackName")["ParameterValue"]
        responseData = get_stack_status(stackName, inputs["is_print_log_enabled"], client)
        pass
    elif(inputs["action"] == "getCFTDetails"):
        check_null_or_blank(inputs["cft_parameters"])
        stackName = next(item for item in inputs["cft_parameters"] if item["ParameterKey"] == "stackName")["ParameterValue"]
        
        # create ec2 client
        ec2_client = create_ec2_client(temp_access_key, temp_secret_access_key, temp_session_token, target_region)
        responseData = get_stack_Details(stackName, inputs["is_print_log_enabled"], client, ec2_client)
        pass
    elif(inputs["action"] == "getEC2InstanceDetails"):
        # create ec2 client
        ec2_client = create_ec2_client(temp_access_key, temp_secret_access_key, temp_session_token, target_region)
        check_null_or_blank(inputs["cft_parameters"])
        instanceId = next(item for item in inputs["cft_parameters"] if item["ParameterKey"] == "instanceId")["ParameterValue"]
        responseData = get_ec2_instance_details(instanceId, inputs["is_print_log_enabled"], ec2_client)
        pass
    elif(inputs["action"] == "startEC2Instance"):
        # create ec2 client
        ec2_client = create_ec2_client(temp_access_key, temp_secret_access_key, temp_session_token, target_region)
        check_null_or_blank(inputs["cft_parameters"])
        instanceId = next(item for item in inputs["cft_parameters"] if item["ParameterKey"] == "instanceId")["ParameterValue"]
        responseData = execute_ec2_power_management(instanceId, "start", inputs["is_print_log_enabled"], ec2_client)
        pass
    elif(inputs["action"] == "stopEC2Instance"):
        # create ec2 client
        ec2_client = create_ec2_client(temp_access_key, temp_secret_access_key, temp_session_token, target_region)
        check_null_or_blank(inputs["cft_parameters"])
        instanceId = next(item for item in inputs["cft_parameters"] if item["ParameterKey"] == "instanceId")["ParameterValue"]
        responseData = execute_ec2_power_management(instanceId, "stop", inputs["is_print_log_enabled"], ec2_client)
        pass
    elif(inputs["action"] == "restartEC2Instance"):
        # create ec2 client
        ec2_client = create_ec2_client(temp_access_key, temp_secret_access_key, temp_session_token, target_region)
        check_null_or_blank(inputs["cft_parameters"])
        instanceId = next(item for item in inputs["cft_parameters"] if item["ParameterKey"] == "instanceId")["ParameterValue"]
        responseData = execute_ec2_power_management(instanceId, "restart", inputs["is_print_log_enabled"], ec2_client)
        pass      
    elif(inputs["action"] == "deleteCFT"):
        check_null_or_blank(inputs["cft_parameters"])
        stackName = next(item for item in inputs["cft_parameters"] if item["ParameterKey"] == "stackName")["ParameterValue"]
        responseData = delete_stack(stackName, inputs["is_print_log_enabled"], client)
        pass
    elif(inputs["action"] == "getTemporaryCredentials"):
        check_null_or_blank(inputs["aws_access_key"])
        check_null_or_blank(inputs["aws_secret_key"])
        check_null_or_blank(inputs["region_name"])
        check_null_or_blank(inputs["role_arn"])       
        credentials = generate_temp_credentials(inputs);
        return credentials;
        pass
    
    return responseData
#
# This code triggers the CloudFormation stack creation
# @param template_name: The CloudFormation template name
# @param parameters: The CloudFormation stack parameters
# @param cfn_client: The CloudFormation client
# @return: The stack ID
# 
def trigger_cft(templateName, parameterBody, isPrintLogEnabled, cfn_client):
    
    responseMessage = {}
    try:
        # Define the CloudFormation stack parameters
        if(parameterBody != []):
            #ec2Name = next(item for item in parameterBody if item["ParameterKey"] == "pEC2Name")["ParameterValue"]
            ec2Name = ""
            for item in parameterBody:
                if(item["ParameterKey"] == "pEC2Name"):
                    ec2Name = item["ParameterValue"]
                    break
            if(ec2Name != ""):
                stack_name = ec2Name+"-stack"
            else:
                stack_name = generate_key()+"-stack"
        else:
            stack_name = generate_key()+"-stack"
        
        with open(templateName, 'r') as f:
            template_body = f.read()
            
        #template_url = None
        parameters = parameterBody
        # Trigger the CloudFormation stack creation
        response = cfn_client.create_stack(
            StackName=stack_name,
            TemplateBody=template_body,
            #TemplateURL=templateUrl,
            Parameters=parameters
        )
        
        if(isPrintLogEnabled == "true"):
            print("stack_name: ", stack_name)
            print("Response: ", response)
            
        # Return the stack ID
        if(response["ResponseMetadata"]["HTTPStatusCode"] == 200):
            responseMessage = {
                "stackId": response["StackId"],
                "requestId": response["ResponseMetadata"]["RequestId"],
                "statusCode": response["ResponseMetadata"]["HTTPStatusCode"],
                "stackName": stack_name,
                "message": "Success"
            }
    except Exception as e:
        if(isPrintLogEnabled == "true"):
            print("Error: ", e)
        responseMessage = {
            "message": "Failure",
            "stackName": stack_name,
            #"error": str(e)
        }

    return json.dumps(responseMessage)
#
# This code triggers the CloudFormation stack creation using url
# @param template_url: The CloudFormation template URL
# @param parameters: The CloudFormation stack parameters
# @param cfn_client: The CloudFormation client
# @return: The stack ID
# 
def trigger_cft_with_url(templateUrl, parameterBody, isPrintLogEnabled, cfn_client):
    responseMessage = {}
    try:
        # Define the CloudFormation stack parameters
        if(parameterBody != []):
            ec2Name = next(item for item in parameterBody if item["ParameterKey"] == "pEC2Name")["ParameterValue"]
            stack_name = ec2Name+"-stack"
        else:
            stack_name = generate_key()+"-stack"
        
        parameters = parameterBody
        # Trigger the CloudFormation stack creation
        response = cfn_client.create_stack(
            StackName=stack_name,
            TemplateURL=templateUrl,
            Parameters=parameters
        )
        
        if(isPrintLogEnabled == "true"):
            print(response)
            
        # Return the stack ID
        if(response["ResponseMetadata"]["HTTPStatusCode"] == 200):
            responseMessage = {
                "stackId": response["StackId"],
                "requestId": response["ResponseMetadata"]["RequestId"],
                "statusCode": response["ResponseMetadata"]["HTTPStatusCode"],
                "stackName": stack_name,
                "message": "Success"
            }
    except Exception as e:
        if(isPrintLogEnabled == "true"):
            print("Error: ", e)
            
        responseMessage = {
            "message": "Failure",
            "stackName": stack_name,
            "error": str(e)
        }
    
    return json.dumps(responseMessage)
#
# This code gets the CloudFormation stack status
# @param stack_name: The CloudFormation stack name
# @param cfn_client: The CloudFormation client
# @return: The stack status
#
def get_stack_status(stackName, isPrintLogEnabled, cfn_client):
    responseMessage = {}
    try:
        stackResponse = cfn_client.describe_stacks(StackName=stackName)
        
        if(isPrintLogEnabled == "true"):
            print(stackResponse)
        
        if(stackResponse is not None):
            responseMessage =  {
                "stackId": stackResponse["Stacks"][0]["StackId"],
                "stackStatus": stackResponse["Stacks"][0]["StackStatus"],
                "stackName": stackName,
                "message": "Success"
            }
    except Exception as e:
        if(isPrintLogEnabled == "true"):
            print("Error: ", e)
            
        responseMessage = {
            "message": "Failure",
            "stackStatus": "Stack with id "+stackName+" does not exist ",
            "stackName": stackName,
            "error": str(e)
        }
        
    return json.dumps(responseMessage)

#
# This code deletes the CloudFormation stack
# @param stack_name: The CloudFormation stack name
# @param cfn_client: The CloudFormation client
# @return: The stack status
#
def delete_stack(stackName, isPrintLogEnabled, cfn_client):
    responseMessage = {}
    try:
        stackResponse = cfn_client.delete_stack(StackName=stackName)
        if(isPrintLogEnabled == "true"):
            print(stackResponse)
        
        if(stackResponse is not None):
            if(stackResponse["ResponseMetadata"]["HTTPStatusCode"] == 200):
                for i in range(3):
                    time.sleep(20)
                    checkCftResult = get_stack_status(stackName, isPrintLogEnabled, cfn_client)
                    if(isPrintLogEnabled == "true"):
                        print("checkCftResult: ", checkCftResult)
                        
                    if("Stack with id "+stackName+" does not exist" in checkCftResult):
                        responseMessage =  {
                            "stackName": stackName,
                            "reason": json.loads(checkCftResult)["error"],
                            "message": "Success",
                            "status": "deleted"
                        }
                        break
                    else:
                        if(i == 2):
                            responseMessage =  {
                                "stackName": stackName,
                                "reason": json.loads(checkCftResult)["stackStatus"],
                                "message": "Failure",
                                "status": "not-deleted"
                            }
    except Exception as e:
        if(isPrintLogEnabled == "true"):
            print("Error: ", e)
        responseMessage = {
            "message": "Failure",
            "stackName": stackName,
            "error": str(e)
        }
        
    return json.dumps(responseMessage)

#
# This code gets the CloudFormation stack details
# @param stack_name: The CloudFormation stack name
# @param cfn_client: The CloudFormation client
# @return: The stack status
#
def get_stack_Details(stackName, isPrintLogEnabled, cfn_client, ec2_client):
    responseMessage = []
    
    try:
        stackResponse = cfn_client.describe_stack_resources(StackName=stackName)
        
        if(isPrintLogEnabled == "true"):
            print("stackResponse: ", stackResponse)
            
        if(stackResponse is not None):
            for stack in stackResponse["StackResources"]:
                
                if(stack["ResourceType"] == "AWS::EC2::Instance"):
                    for i in range(5):
                        time.sleep(20)
                        ec2Response = get_ec2_instance_details(stack["PhysicalResourceId"], isPrintLogEnabled, ec2_client)
                        
                        if(isPrintLogEnabled == "true"):
                            print("ec2Response: ", ec2Response)
                            
                        ec2json = json.loads(ec2Response)
                        if(ec2json["status"] == "running"):
                            privateIpAddress = ec2json["privateIpAddress"]
                            responseMessage.append({
                                "stackId": stack["StackId"],
                                "stackStatus": stack["ResourceStatus"],
                                "stackName": stackName,
                                "resourceType": stack["ResourceType"],
                                "instanceId": stack["PhysicalResourceId"],
                                "privateIpAddress": privateIpAddress,
                                "privateDNSName": ec2json["privateDNSName"],
                                "publicDNSName": ec2json["publicDNSName"],
                                "securityGroups": ec2json["securityGroups"],
                                "ownerId": ec2json["ownerId"],
                                "status": ec2json["status"],
                                "message": "Success"
                            })
                        break
    except Exception as e:
        if(isPrintLogEnabled == "true"):
            print("Error: ", e)
            
        responseMessage = {
            "message": "Failure",
            "stackName": stackName,
            "error": str(e)
        }
        
    return json.dumps(responseMessage)


#
# This code gets ec2 instance details
# @param instance_id: The ec2 instance id
# @param ec2_client: The ec2 client
# @return: The ec2 instance details
#
def get_ec2_instance_details(instance_id, isPrintLogEnabled, ec2_client):
    responseMessage = {}
    
    try:
        ec2Response = ec2_client.describe_instances(InstanceIds=[instance_id])
        if(isPrintLogEnabled == "true"):
            print("ec2Response: ", ec2Response)
            
        if(ec2Response is not None):
            state = ec2Response["Reservations"][0]["Instances"][0]["State"]["Name"]
            if(state == "running"):
                responseMessage = {
                    "status": state,
                    "instanceId": instance_id,
                    "privateIpAddress": ec2Response["Reservations"][0]["Instances"][0]["PrivateIpAddress"],
                    "privateDNSName": ec2Response["Reservations"][0]["Instances"][0]["PrivateDnsName"],
                    "publicDNSName": ec2Response["Reservations"][0]["Instances"][0]["PublicDnsName"],
                    "securityGroups": ec2Response["Reservations"][0]["Instances"][0]["SecurityGroups"],
                    "ownerId": ec2Response["Reservations"][0]["OwnerId"],
                    "message": "Success"
                }
            else:
                responseMessage = {
                    "message": "Success",
                    "instanceId": instance_id,
                    "status": state
                }
    except Exception as e:
        if(isPrintLogEnabled == "true"):
            print("Error: ", e)
            
        responseMessage = {
            "message": "Failure",
            "instanceId": instance_id,
            "error": str(e)
        }
        
        
    return json.dumps(responseMessage)


#
# This code checks ec2 instance status
# @param instance_id: The ec2 instance id
# @param ec2_client: The ec2 client
# @return: The ec2 instance details
#
def check_ec2_instance_status(instance_id, isPrintLogEnabled, ec2_client):
    responseMessage = {}
    
    try:
        ec2Response = ec2_client.describe_instances(InstanceIds=[instance_id])
        if(isPrintLogEnabled == "true"):
            print("ec2Response: ", ec2Response)
            
        if(ec2Response is not None):
            state = ec2Response["Reservations"][0]["Instances"][0]["State"]["Name"]
            responseMessage = {
                "status": state,
                "instanceId": instance_id,
                "message": "Success"
            }
    except Exception as e:
        if(isPrintLogEnabled == "true"):
            print("Error: ", e)
            
        responseMessage = {
            "message": "Failure",
            "instanceId": instance_id,
            "error": str(e)
        }
        
    return json.dumps(responseMessage)

#
# This code stop/starts ec2 instance
# @param instance_id: The ec2 instance id
# @param ec2_client: The 2c2 client
# @return: The ec2 status details
#
def execute_ec2_power_management(instance_id, action, isPrintLogEnabled, ec2_client):
    responseMessage = {}
    
    try:
        if(action == "start"):
            ec2Response = ec2_client.start_instances(InstanceIds=[instance_id])
        elif(action == "stop"):
            ec2Response = ec2_client.stop_instances(InstanceIds=[instance_id])
        elif(action == "restart"):
            ec2Response = ec2_client.reboot_instances(InstanceIds=[instance_id])
        
        if(isPrintLogEnabled == "true"):
            print("ec2Response: ", ec2Response)
            
        time.sleep(20)
        if(ec2Response is not None):
            httpStatus = ec2Response["ResponseMetadata"]["HTTPStatusCode"]    
            if(httpStatus == 200):
                statusResponse = check_ec2_instance_status(instance_id, isPrintLogEnabled, ec2_client)
                if(isPrintLogEnabled == "true"):
                    print("statusResponse: ", statusResponse)
                    
                statusJson = json.loads(statusResponse)
                if(statusResponse is not None):
                    state = statusJson["status"]
                    responseMessage = {
                        "status": state,
                        "instanceId": instance_id,
                        "message": "Success"
                    }
            else:
                responseMessage = {
                    "message": "Failure",
                    "instanceId": instance_id,
                    "error": str(ec2Response)
                }
    except Exception as e:
        if(isPrintLogEnabled == "true"):
            print("Error: ", e)
            
        responseMessage = {
            "message": "Failure",
            "instanceId": instance_id,
            "error": str(e)
        }
        
        
    return json.dumps(responseMessage)
