import boto3
import random
import string
import json

#
# This code checks if the input is null or blank
# @param variable: The variable to be checked
# @return: None
# @raise ValueError: If the variable is null or blank
#
def check_null_or_blank(variable):
    if variable is None or variable == '':
        raise ValueError('Variable is null or blank')

#
# This code generates a random key
# @param: None
# @return: The generated key
#
def generate_key():
    letters_and_digits = string.ascii_letters + string.digits
    return ''.join(random.choice(letters_and_digits) for i in range(20))

#
# This code generates temporary credentials using the STS AssumeRole operation
# @param inputs: The input parameters required to generate the temporary credentials
# @return: The temporary credentials
#
def generate_temp_credentials(inputs):
    sts_client = boto3.client(
        'sts',
        aws_access_key_id=inputs["aws_access_key"],
        aws_secret_access_key=inputs["aws_secret_key"],
        region_name=inputs["region_name"]
    )

    # Define the AssumeRole request parameters
    role_arn = inputs["role_arn"]
    role_session_name = generate_key()
    #print(role_session_name)
    # Send the AssumeRole request
    response = sts_client.assume_role(
        RoleArn=role_arn,
        RoleSessionName=role_session_name
    )
    # Extract the temporary credentials from the response
    access_key_id = response['Credentials']['AccessKeyId']
    secret_access_key = response['Credentials']['SecretAccessKey']
    session_token = response['Credentials']['SessionToken']

    return {
        "access_key_id": access_key_id,
        "secret_access_key": secret_access_key,
        "session_token": session_token
    }

#
# This code creates a CloudFormation client using the temporary credentials
# @param access_key_id: The temporary access key ID
# @param secret_access_key: The temporary secret access key
# @param session_token: The temporary session token
# @param target_region: The target region
# @return: The CloudFormation client
# 
def create_cfn_client(access_key_id, secret_access_key, session_token, target_region):
    # Use the temporary credentials to create a CloudFormation client in the target account
    cfn_client = boto3.client(
        'cloudformation',
        aws_access_key_id=access_key_id,
        aws_secret_access_key=secret_access_key,
        aws_session_token=session_token,
        region_name=target_region
    )  
    return cfn_client

#
# This code is the main function
# @param context: The Lambda context object
# @param inputs: The input parameters required to execute the action
# @return: The output of the action
# 
def handler(context, inputs):
    # Define the STS client

    print("Inputs: ", inputs)
    responseData = ""
    if(inputs["cftParameters"] != []):
        for item in inputs["cftParameters"]:
            print(item["ParameterKey"]+" : "+item["ParameterValue"])

    # Check if the inputs are null or blank
    if(inputs is not None):
        check_null_or_blank(inputs["action"])
        check_null_or_blank(inputs["aws_access_key"])
        check_null_or_blank(inputs["aws_secret_key"])
        check_null_or_blank(inputs["region_name"])
        check_null_or_blank(inputs["role_arn"])
        check_null_or_blank(inputs["target_region"])
        
        # Generate temporary credentials
        credentials = generate_temp_credentials(inputs);
        temp_access_key = credentials["access_key_id"]
        temp_secret_access_key = credentials["secret_access_key"]
        temp_session_token = credentials["session_token"]
        target_region = inputs["target_region"]
        
        # create cfn client
        client = create_cfn_client(temp_access_key, temp_secret_access_key, temp_session_token, target_region)
        
    # Execute based on action
    if(inputs["action"] == "executeCFT"):
        check_null_or_blank(inputs["templateName"])
        check_null_or_blank(inputs["cftParameters"])
        responseData = trigger_cft(inputs["templateName"], inputs["cftParameters"], client)
        #print(responseData)
        pass
    elif(inputs["action"] == "executeCFTWithUrl"):
        check_null_or_blank(inputs["templateUrl"])
        check_null_or_blank(inputs["cftParameters"])
        responseData = trigger_cft(inputs["templateUrl"], inputs["cftParameters"], client)
        pass
    elif(inputs["action"] == "getCFTStatus"):
        check_null_or_blank(inputs["cftParameters"])
        stackName = next(item for item in inputs["cftParameters"] if item["ParameterKey"] == "stackName")["ParameterValue"]
        #print(stackName)
        responseData = get_stack_status(stackName, client)
        #print(responseData)
        pass
    elif(inputs["action"] == "getTemporaryCredentials"):
        check_null_or_blank(inputs["aws_access_key"])
        check_null_or_blank(inputs["aws_secret_key"])
        check_null_or_blank(inputs["region_name"])
        check_null_or_blank(inputs["role_arn"])       
        credentials = generate_temp_credentials(inputs);
        return credentials;
        pass
    
    return responseData
#
# This code triggers the CloudFormation stack creation
# @param template_name: The CloudFormation template name
# @param parameters: The CloudFormation stack parameters
# @param cfn_client: The CloudFormation client
# @return: The stack ID
# 
def trigger_cft(templateName, parameterBody, cfn_client):
    
    responseMessage = {}
    try:
        # Define the CloudFormation stack parameters
        if(parameterBody != []):
            ec2Name = next(item for item in parameterBody if item["ParameterKey"] == "pEC2Name")["ParameterValue"]
            stack_name = ec2Name+"-stack"
        else:
            stack_name = generate_key()+"-stack"
        
        with open(templateName, 'r') as f:
            template_body = f.read()
            
        print("stack_name: ", stack_name)
        #template_url = None
        parameters = parameterBody
        # Trigger the CloudFormation stack creation
        response = cfn_client.create_stack(
            StackName=stack_name,
            TemplateBody=template_body,
            #TemplateURL=templateUrl,
            Parameters=parameters
        )
        print(response)
        # Return the stack ID
        if(response["ResponseMetadata"]["HTTPStatusCode"] == 200):
            responseMessage = {
                "stackId": response["StackId"],
                "requestId": response["ResponseMetadata"]["RequestId"],
                "statusCode": response["ResponseMetadata"]["HTTPStatusCode"],
                "stackName": stack_name,
                "response": response,
                "message": "Success"
            }
    except Exception as e:
        print("Error: ", e)
        responseMessage = {
            "message": "Failure",
            "stackName": stack_name,
            "response": response,
            "error": str(e)
        }

    return json.dumps(responseMessage)
#
# This code triggers the CloudFormation stack creation using url
# @param template_url: The CloudFormation template URL
# @param parameters: The CloudFormation stack parameters
# @param cfn_client: The CloudFormation client
# @return: The stack ID
# 
def trigger_cft_with_url(templateUrl, parameterBody, cfn_client):
    responseMessage = {}
    try:
        # Define the CloudFormation stack parameters
        if(parameterBody != []):
            ec2Name = next(item for item in parameterBody if item["ParameterKey"] == "pEC2Name")["ParameterValue"]
            stack_name = ec2Name+"-stack"
        else:
            stack_name = generate_key()+"-stack"
        
        parameters = parameterBody
        # Trigger the CloudFormation stack creation
        response = cfn_client.create_stack(
            StackName=stack_name,
            TemplateURL=templateUrl,
            Parameters=parameters
        )
        #print(response)
        # Return the stack ID
        if(response["ResponseMetadata"]["HTTPStatusCode"] == 200):
            responseMessage = {
                "stackId": response["StackId"],
                "requestId": response["ResponseMetadata"]["RequestId"],
                "statusCode": response["ResponseMetadata"]["HTTPStatusCode"],
                "stackName": stack_name,
                "response": response,
                "message": "Success"
            }
    except Exception as e:
        #print("Error: ", e)
        responseMessage = {
            "message": "Failure",
            "stackName": stack_name,
            "response": response,
            "error": str(e)
        }
    
    return json.dumps(responseMessage)
#
# This code gets the CloudFormation stack status
# @param stack_name: The CloudFormation stack name
# @param cfn_client: The CloudFormation client
# @return: The stack status
#
def get_stack_status(stackName, cfn_client):
    responseMessage = {}
    try:
        stackResponse = cfn_client.describe_stacks(StackName=stackName)
        if(stackResponse is not None):
            responseMessage =  {
                "stackId": stackResponse["Stacks"][0]["StackId"],
                "stackStatus": stackResponse["Stacks"][0]["StackStatus"],
                "stackName": stackName,
                "statusResponse": stackResponse,
                "message": "Success"
            }
    except Exception as e:
        #print("Error: ", e)
        responseMessage = {
            "message": "Failure",
            "stackName": stackName,
            "response": stackResponse,
            "error": str(e)
        }
        
    return json.dumps(responseMessage)
