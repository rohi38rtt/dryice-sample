import boto3

def handler(context, inputs):
# Define the STS client
    Values = inputs["TestKey"]
    print(Values)

    sts_client = boto3.client(
        'sts',
        aws_access_key_id=inputs["aws_access_key_id"],
        aws_secret_access_key=inputs["aws_secret_access_key"],
        region_name=inputs["region_name"]
    )

    # Define the AssumeRole request parameters
    role_arn = inputs["role_arn"]
    role_session_name = inputs["role_session_name"]

    # Send the AssumeRole request
    response = sts_client.assume_role(
        RoleArn=role_arn,
        RoleSessionName=role_session_name
    )

    # Extract the temporary credentials from the response
    access_key_id = response['Credentials']['AccessKeyId']
    secret_access_key = response['Credentials']['SecretAccessKey']
    session_token = response['Credentials']['SessionToken']

    # Use the temporary credentials to create a CloudFormation client in the target account
    cfn_client = boto3.client(
        'cloudformation',
        aws_access_key_id=access_key_id,
        aws_secret_access_key=secret_access_key,
        aws_session_token=session_token,
        region_name=inputs["TargetDeploymentRegion"]
    )

    # Define the CloudFormation stack parameters
    stack_name = inputs["stack_name"]
    with open(inputs["TemplateName"], 'r') as f:
        template_body = f.read()
    parameters = [
        {
            'ParameterKey': 'InstanceTypeParameter',
            'ParameterValue': 't2.micro'
        }
    ]
    # Trigger the CloudFormation stack creation
    response = cfn_client.create_stack(
        StackName=stack_name,
        TemplateBody=template_body,
        Parameters=parameters
    )
    print(response)
